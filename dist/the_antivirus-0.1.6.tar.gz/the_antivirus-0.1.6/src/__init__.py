from .main import AntivirusApp

__all__ = ["AntivirusApp"]

__version__ = "0.1.6"
__author__ = "Daniel Grosso"